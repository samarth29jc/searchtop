package payments

var CountryData = map[string][]struct {
	Address1           string `json:"address1"`
	Address2           string `json:"address2"`
	AdministrativeArea string `json:"administrativeArea"`
	Country            string `json:"country"`
	Locality           string `json:"locality"`
	PostalCode         string `json:"postalCode"`
}{
	"IN":{
		{
			"address1": "123 MG Road",
			"address2": "Apt 4B",
			"administrativeArea": "Karnataka",
			"country": "India",
			"locality": "Bengaluru",
			"postalCode": "560001"
		  },
		  {
			"address1": "Plot No 78, Sector 21",
			"address2": "Dwarka",
			"administrativeArea": "Delhi",
			"country": "India",
			"locality": "New Delhi",
			"postalCode": "110075"
		  },
		  {
			"address1": "12 Park Street",
			"address2": "Flat 3A",
			"administrativeArea": "West Bengal",
			"country": "India",
			"locality": "Kolkata",
			"postalCode": "700016"
		  },
		  {
			"address1": "H.No. 102, Jubilee Hills",
			"address2": "Road No. 10",
			"administrativeArea": "Telangana",
			"country": "India",
			"locality": "Hyderabad",
			"postalCode": "500033"
		  },
		  {
			"address1": "5/12, FC Road",
			"address2": "Shivajinagar",
			"administrativeArea": "Maharashtra",
			"country": "India",
			"locality": "Pune",
			"postalCode": "411005"
		  },
		  {
			"address1": "B-15, South Extension",
			"address2": "Part-1",
			"administrativeArea": "Delhi",
			"country": "India",
			"locality": "New Delhi",
			"postalCode": "110049"
		  },
		  {
			"address1": "G-45, Sector 18",
			"address2": "Noida",
			"administrativeArea": "Uttar Pradesh",
			"country": "India",
			"locality": "Noida",
			"postalCode": "201301"
		  },
	},

"GB":{
	{
		"address1": "10 Downing Street",
		"address2": "Cabinet Office",
		"administrativeArea": "Greater London",
		"country": "GB",
		"locality": "London",
		"postalCode": "SW1A 2AA"
	},
	{
		"address1": "221B Baker Street",
		"address2": "Sherlock Holmes Museum",
		"administrativeArea": "Greater London",
		"country": "GB",
		"locality": "London",
		"postalCode": "NW1 6XE"
	},
	{
		"address1": "50 George Square",
		"address2": "University of Edinburgh Main Campus",
		"administrativeArea": "Scotland",
		"country": "GB",
		"locality": "Edinburgh",
		"postalCode": "EH8 9JU"
	},
	{
		"address1": "100 Oxford Street",
		"address2": "2nd Floor, Next to Zara",
		"administrativeArea": "Greater London",
		"country": "GB",
		"locality": "London",
		"postalCode": "W1D 1LL"
	},
	{
		"address1": "8 Castle Street",
		"address2": "Above HSBC Bank",
		"administrativeArea": "Merseyside",
		"country": "GB",
		"locality": "Liverpool",
		"postalCode": "L2 0NE"
	},
	{
		"address1": "1 Cornmarket Street",
		"address2": "Opposite Clarendon Centre",
		"administrativeArea": "Oxfordshire",
		"country": "GB",
		"locality": "Oxford",
		"postalCode": "OX1 3EY"
	},
	{
		"address1": "34 St Andrew’s Street",
		"address2": "Trinity College Front Office",
		"administrativeArea": "Cambridgeshire",
		"country": "GB",
		"locality": "Cambridge",
		"postalCode": "CB2 3AR"
	},
	{
		"address1": "Manchester Town Hall",
		"address2": "Main Civic Building",
		"administrativeArea": "Greater Manchester",
		"country": "GB",
		"locality": "Manchester",
		"postalCode": "M2 5DB"
	},
	{
		"address1": "77 Queen Street",
		"address2": "2nd Floor, Exchange Tower",
		"administrativeArea": "Lanarkshire",
		"country": "GB",
		"locality": "Glasgow",
		"postalCode": "G1 3DN"
	},
	{
		"address1": "23 Bondgate Within",
		"address2": "Next to Post Office",
		"administrativeArea": "County Durham",
		"country": "GB",
		"locality": "Darlington",
		"postalCode": "DL3 7JU"
	}
	},

"KZ":{
	{
		"address1": "56 Bogenbay Batyr Street",
		"address2": "Almaly Business Center, Suite 501",
		"administrativeArea": "Almaty",
		"country": "KZ",
		"locality": "Almaty",
		"postalCode": "050010"
	  },
	  {
		"address1": "17 Dostyk Avenue",
		"address2": "Megacenter Shopping Complex, 3rd Floor",
		"administrativeArea": "Almaty",
		"country": "KZ",
		"locality": "Almaty",
		"postalCode": "050059"
	  },
	  {
		"address1": "3 Republic Avenue",
		"address2": "Astana City Tower, 14th Floor",
		"administrativeArea": "Astana",
		"country": "KZ",
		"locality": "Astana",
		"postalCode": "010000"
	  },
	  {
		"address1": "14 Abay Street",
		"address2": "Shymkent Plaza, Office 202",
		"administrativeArea": "Shymkent",
		"country": "KZ",
		"locality": "Shymkent",
		"postalCode": "160012"
	  },
	  {
		"address1": "88 Tole Bi Street",
		"address2": "Opposite Park Hotel, 2nd Floor",
		"administrativeArea": "Almaty",
		"country": "KZ",
		"locality": "Almaty",
		"postalCode": "050000"
	  },
	  {
		"address1": "1 Tauelsizdik Avenue",
		"address2": "Independence Palace, Level 1",
		"administrativeArea": "Astana",
		"country": "KZ",
		"locality": "Astana",
		"postalCode": "010000"
	  },
	  {
		"address1": "20 Kurmangazy Street",
		"address2": "Kurmangazy Trade Center, Block A",
		"administrativeArea": "Atyrau Region",
		"country": "KZ",
		"locality": "Atyrau",
		"postalCode": "060011"
	  },
	  {
		"address1": "12 Satpaev Street",
		"address2": "Pavlodar Central Market, Shop 8B",
		"administrativeArea": "Pavlodar Region",
		"country": "KZ",
		"locality": "Pavlodar",
		"postalCode": "140000"
	  },
	  {
		"address1": "5 Kabanbay Batyr Avenue",
		"address2": "Exhibition Center, Hall 3",
		"administrativeArea": "Astana",
		"country": "KZ",
		"locality": "Astana",
		"postalCode": "010000"
	  },
	  {
		"address1": "33 Abylai Khan Avenue",
		"address2": "Alatau Tower, Office 512",
		"administrativeArea": "Almaty",
		"country": "KZ",
		"locality": "Almaty",
		"postalCode": "050057"
	  }
},

"EE":{
	{
		"address1": "Rävala pst 5",
		"address2": "3rd Floor, Room 302",
		"administrativeArea": "Harju County",
		"country": "EE",
		"locality": "Tallinn",
		"postalCode": "10143"
	},
	{
		"address1": "Tartu mnt 67",
		"address2": "Delta Building, Block B",
		"administrativeArea": "Harju County",
		"country": "EE",
		"locality": "Tallinn",
		"postalCode": "10115"
	},
	{
		"address1": "Narva mnt 25",
		"address2": "Unit 6A",
		"administrativeArea": "Harju County",
		"country": "EE",
		"locality": "Tallinn",
		"postalCode": "10120"
	},
	{
		"address1": "Liivalaia 12",
		"address2": "Office 410",
		"administrativeArea": "Harju County",
		"country": "EE",
		"locality": "Tallinn",
		"postalCode": "10118"
	},
	{
		"address1": "Vallikraavi 4",
		"address2": "Building A, 2nd Floor",
		"administrativeArea": "Tartu County",
		"country": "EE",
		"locality": "Tartu",
		"postalCode": "51003"
	},
	{
		"address1": "Ülikooli 18",
		"address2": "Faculty of Economics",
		"administrativeArea": "Tartu County",
		"country": "EE",
		"locality": "Tartu",
		"postalCode": "51014"
	},
	{
		"address1": "Pikk 36",
		"address2": "Apartment 7",
		"administrativeArea": "Harju County",
		"country": "EE",
		"locality": "Tallinn",
		"postalCode": "10133"
	},
	{
		"address1": "Viru väljak 4",
		"address2": "Suite 504",
		"administrativeArea": "Harju County",
		"country": "EE",
		"locality": "Tallinn",
		"postalCode": "10111"
	},
	{
		"address1": "Roosikrantsi 11",
		"address2": "Attic Office",
		"administrativeArea": "Harju County",
		"country": "EE",
		"locality": "Tallinn",
		"postalCode": "10119"
	},
	{
		"address1": "Riia 24",
		"address2": "Room 209, Block B",
		"administrativeArea": "Tartu County",
		"country": "EE",
		"locality": "Tartu",
		"postalCode": "51010"
	}
},
"CH":{

	{
		"address1": "Bahnhofstrasse 10",
		"address2": "Suite 501",
		"administrativeArea": "Zurich",
		"country": "CH",
		"locality": "Zurich",
		"postalCode": "8001"
	},
	{
		"address1": "Rue du Rhône 65",
		"address2": "4th Floor",
		"administrativeArea": "Geneva",
		"country": "CH",
		"locality": "Geneva",
		"postalCode": "1204"
	},
	{
		"address1": "Aeschenplatz 6",
		"address2": "2nd Floor, Office 203",
		"administrativeArea": "Basel-Stadt",
		"country": "CH",
		"locality": "Basel",
		"postalCode": "4052"
	},
	{
		"address1": "Bahnhofplatz 1",
		"address2": "Building C, Room 305",
		"administrativeArea": "Bern",
		"country": "CH",
		"locality": "Bern",
		"postalCode": "3011"
	},
	{
		"address1": "Seefeldstrasse 45",
		"address2": "Top Floor, Room 12",
		"administrativeArea": "Zurich",
		"country": "CH",
		"locality": "Zurich",
		"postalCode": "8008"
	},
	{
		"address1": "Postgasse 20",
		"address2": "Suite 6A",
		"administrativeArea": "Bern",
		"country": "CH",
		"locality": "Bern",
		"postalCode": "3011"
	},
	{
		"address1": "Place de la Gare 12",
		"address2": "Office 102",
		"administrativeArea": "Vaud",
		"country": "CH",
		"locality": "Lausanne",
		"postalCode": "1003"
	},
	{
		"address1": "Rennweg 30",
		"address2": "Apartment 3C",
		"administrativeArea": "Zurich",
		"country": "CH",
		"locality": "Zurich",
		"postalCode": "8001"
	},
	{
		"address1": "Via Nassa 21",
		"address2": "Business Center Floor 2",
		"administrativeArea": "Ticino",
		"country": "CH",
		"locality": "Lugano",
		"postalCode": "6900"
	},
	{
		"address1": "Hohlstrasse 35",
		"address2": "Building A, Room 22",
		"administrativeArea": "Zurich",
		"country": "CH",
		"locality": "Zurich",
		"postalCode": "8004"
	}
},
"IE":{
	{
		"address1": "5 Merrion Square North",
		"address2": "2nd Floor, Suite B",
		"administrativeArea": "County Dublin",
		"country": "IE",
		"locality": "Dublin",
		"postalCode": "D02 TF30"
	  },
	  {
		"address1": "16 St. Stephen's Green",
		"address2": "Office 405",
		"administrativeArea": "County Dublin",
		"country": "IE",
		"locality": "Dublin",
		"postalCode": "D02 VW90"
	  },
	  {
		"address1": "Unit 2, River House",
		"address2": "3rd Floor",
		"administrativeArea": "County Cork",
		"country": "IE",
		"locality": "Cork",
		"postalCode": "T12 E299"
	  },
	  {
		"address1": "32 Eyre Square",
		"address2": "Suite 1B",
		"administrativeArea": "County Galway",
		"country": "IE",
		"locality": "Galway",
		"postalCode": "H91 NFD2"
	  },
	  {
		"address1": "National Technology Park",
		"address2": "Innovation House",
		"administrativeArea": "County Limerick",
		"country": "IE",
		"locality": "Limerick",
		"postalCode": "V94 Y394"
	  },
	  {
		"address1": "1 George's Quay",
		"address2": "Office 211",
		"administrativeArea": "County Dublin",
		"country": "IE",
		"locality": "Dublin",
		"postalCode": "D02 K793"
	  },
	  {
		"address1": "EastPoint Business Park",
		"address2": "Block D, Suite 4",
		"administrativeArea": "County Dublin",
		"country": "IE",
		"locality": "Dublin",
		"postalCode": "D03 XH70"
	  },
	  {
		"address1": "Unit 12A, Parkmore Business Park",
		"address2": "Ground Floor",
		"administrativeArea": "County Galway",
		"country": "IE",
		"locality": "Galway",
		"postalCode": "H91 DYT9"
	  },
	  {
		"address1": "IDA Business Park",
		"address2": "Building 3, Suite 6",
		"administrativeArea": "County Waterford",
		"country": "IE",
		"locality": "Waterford",
		"postalCode": "X91 D2EF"
	  },
	  {
		"address1": "Blackrock Business Park",
		"address2": "Level 1, Block B",
		"administrativeArea": "County Dublin",
		"country": "IE",
		"locality": "Blackrock",
		"postalCode": "A94 F7X8"
	  }
},

"SI":{
	{
		"address1": "Dunajska cesta 20",
		"address2": "2nd Floor, Office 14",
		"administrativeArea": "Osrednjeslovenska",
		"country": "SI",
		"locality": "Ljubljana",
		"postalCode": "1000"
	  },
	  {
		"address1": "Slovenska cesta 56",
		"address2": "Business Center, Suite 501",
		"administrativeArea": "Osrednjeslovenska",
		"country": "SI",
		"locality": "Ljubljana",
		"postalCode": "1000"
	  },
	  {
		"address1": "Tržaška cesta 2",
		"address2": "Building A, Room 3",
		"administrativeArea": "Osrednjeslovenska",
		"country": "SI",
		"locality": "Ljubljana",
		"postalCode": "1000"
	  },
	  {
		"address1": "Koroška cesta 14",
		"address2": "3rd Floor, Unit C",
		"administrativeArea": "Podravska",
		"country": "SI",
		"locality": "Maribor",
		"postalCode": "2000"
	  },
	  {
		"address1": "Kidričeva ulica 9",
		"address2": "Apartment 22",
		"administrativeArea": "Savinjska",
		"country": "SI",
		"locality": "Celje",
		"postalCode": "3000"
	  },
	  {
		"address1": "Glavni trg 1",
		"address2": "Suite 4A",
		"administrativeArea": "Gorenjska",
		"country": "SI",
		"locality": "Kranj",
		"postalCode": "4000"
	  },
	  {
		"address1": "Postojnska ulica 2",
		"address2": "Ground Floor",
		"administrativeArea": "Primorsko-notranjska",
		"country": "SI",
		"locality": "Postojna",
		"postalCode": "6230"
	  },
	  {
		"address1": "Kidričeva cesta 1",
		"address2": "Office 103",
		"administrativeArea": "Jugovzhodna Slovenija",
		"country": "SI",
		"locality": "Novo Mesto",
		"postalCode": "8000"
	  },
	  {
		"address1": "Gregorčičeva ulica 10",
		"address2": "Penthouse",
		"administrativeArea": "Goriška",
		"country": "SI",
		"locality": "Nova Gorica",
		"postalCode": "5000"
	  },
	  {
		"address1": "Titov trg 5",
		"address2": "Suite 12",
		"administrativeArea": "Obalno-kraška",
		"country": "SI",
		"locality": "Koper",
		"postalCode": "6000"
	  }
},
"HR":{
	{
		"address1": "Trg bana Josipa Jelačića 1",
		"address2": "Apartment 5A",
		"administrativeArea": "Grad Zagreb",
		"country": "HR",
		"locality": "Zagreb",
		"postalCode": "10000"
	  },
	  {
		"address1": "Ulica Ivana Tkalčića 32",
		"address2": "Suite 3",
		"administrativeArea": "Grad Zagreb",
		"country": "HR",
		"locality": "Zagreb",
		"postalCode": "10000"
	  },
	  {
		"address1": "Riva 18",
		"address2": "Seaside View",
		"administrativeArea": "Splitsko-dalmatinska županija",
		"country": "HR",
		"locality": "Split",
		"postalCode": "21000"
	  },
	  {
		"address1": "Ulica kralja Petra Krešimira IV 10",
		"address2": "Building B, Apt 8",
		"administrativeArea": "Primorsko-goranska županija",
		"country": "HR",
		"locality": "Rijeka",
		"postalCode": "51000"
	  },
	  {
		"address1": "Opatijska ulica 5",
		"address2": "Villa Lavanda",
		"administrativeArea": "Istarska županija",
		"country": "HR",
		"locality": "Pula",
		"postalCode": "52100"
	  }	
},

"AT":{
	{
		"address1": "Stephansplatz 1",
		"address2": "Suite 12",
		"administrativeArea": "Wien",
		"country": "AT",
		"locality": "Vienna",
		"postalCode": "1010"
	  },
	  {
		"address1": "Mariahilfer Straße 99",
		"address2": "Office 23A",
		"administrativeArea": "Wien",
		"country": "AT",
		"locality": "Vienna",
		"postalCode": "1060"
	  },
	  {
		"address1": "Getreidegasse 3",
		"address2": "Mozart's Birthplace",
		"administrativeArea": "Salzburg",
		"country": "AT",
		"locality": "Salzburg",
		"postalCode": "5020"
	  },
	  {
		"address1": "Landstraße 20",
		"address2": "Business Center 4",
		"administrativeArea": "Oberösterreich",
		"country": "AT",
		"locality": "Linz",
		"postalCode": "4020"
	  },
	  {
		"address1": "Rennweg 16",
		"address2": "Building D, Room 45",
		"administrativeArea": "Wien",
		"country": "AT",
		"locality": "Vienna",
		"postalCode": "1030"
	  }	
},
"FI":{
	{
		"address1": "Mannerheimintie 15",
		"address2": "Suite 303",
		"administrativeArea": "Uusimaa",
		"country": "FI",
		"locality": "Helsinki",
		"postalCode": "00100"
	  },
	  {
		"address1": "Esplanadi 25",
		"address2": "Apartment 7B",
		"administrativeArea": "Uusimaa",
		"country": "FI",
		"locality": "Helsinki",
		"postalCode": "00130"
	  },
	  {
		"address1": "Kauppatori 5",
		"address2": "Harbor View",
		"administrativeArea": "Uusimaa",
		"country": "FI",
		"locality": "Helsinki",
		"postalCode": "00170"
	  },
	  {
		"address1": "Hatanpään valtatie 3",
		"address2": "Building 2, Office 5A",
		"administrativeArea": "Pirkanmaa",
		"country": "FI",
		"locality": "Tampere",
		"postalCode": "33100"
	  },
	  {
		"address1": "Lönnrotinkatu 18",
		"address2": "Penthouse",
		"administrativeArea": "Uusimaa",
		"country": "FI",
		"locality": "Helsinki",
		"postalCode": "00120"
	  }
},
"RS":{
	{
		"address1": "Knez Mihailova 10",
		"address2": "Old Town",
		"administrativeArea": "Belgrade",
		"country": "RS",
		"locality": "Belgrade",
		"postalCode": "11000"
	  },
	  {
		"address1": "Bulevar Kralja Aleksandra 45",
		"address2": "Apartment 3C",
		"administrativeArea": "Belgrade",
		"country": "RS",
		"locality": "Belgrade",
		"postalCode": "11060"
	  },
	  {
		"address1": "Cara Dušana 16",
		"address2": "Office Floor 2",
		"administrativeArea": "Novi Sad",
		"country": "RS",
		"locality": "Novi Sad",
		"postalCode": "21000"
	  },
	  {
		"address1": "Zmaj Jovina 21",
		"address2": "Business Tower",
		"administrativeArea": "Novi Sad",
		"country": "RS",
		"locality": "Novi Sad",
		"postalCode": "21000"
	  },
	  {
		"address1": "Nikole Tesle 11",
		"address2": "Innovation Hub",
		"administrativeArea": "Niš",
		"country": "RS",
		"locality": "Niš",
		"postalCode": "18000"
	  }
},

"BA":{
	{
		"address1": "Maršala Tita 7",
		"address2": "Penthouse Suite",
		"administrativeArea": "Sarajevo",
		"country": "BA",
		"locality": "Sarajevo",
		"postalCode": "71000"
	  },
	  {
		"address1": "Ferhadija 12",
		"address2": "Historic Center",
		"administrativeArea": "Sarajevo",
		"country": "BA",
		"locality": "Sarajevo",
		"postalCode": "71000"
	  },
	  {
		"address1": "Tuzlanska 14",
		"address2": "Building C, Apt 4B",
		"administrativeArea": "Tuzla",
		"country": "BA",
		"locality": "Tuzla",
		"postalCode": "75000"
	  },
	  {
		"address1": "Kralja Tvrtka 9",
		"address2": "City Center",
		"administrativeArea": "Mostar",
		"country": "BA",
		"locality": "Mostar",
		"postalCode": "88000"
	  }
},

"MK":{
	{
		"address1": "Makedonija Street 15",
		"address2": "Business Floor 5",
		"administrativeArea": "Skopje",
		"country": "MK",
		"locality": "Skopje",
		"postalCode": "1000"
	  },
	  {
		"address1": "Dame Gruev 22",
		"address2": "Shopping District",
		"administrativeArea": "Skopje",
		"country": "MK",
		"locality": "Skopje",
		"postalCode": "1000"
	  },
	  {
		"address1": "Maršala Tita 9",
		"address2": "Office Block A",
		"administrativeArea": "Bitola",
		"country": "MK",
		"locality": "Bitola",
		"postalCode": "7000"
	  }
},
"MK":{
	{
		"Address1": "12 Dimitrie Chupovski Street",
		"Address2": "Apartment 5B",
		"AdministrativeArea": "",
		"Country": "North Macedonia",
		"Locality": "Skopje",
		"PostalCode": "1000"
	  },
	  {
		"Address1": "Bul. Partizanski Odredi 70",
		"Address2": "Suite 201",
		"AdministrativeArea": "",
		"Country": "North Macedonia",
		"Locality": "Skopje",
		"PostalCode": "1000"
	  },
	  {
		"Address1": "Kej Dimitar Vlahov bb",
		"Address2": "Floor 4, Office 6",
		"AdministrativeArea": "",
		"Country": "North Macedonia",
		"Locality": "Skopje",
		"PostalCode": "1000"
	  },
	  {
		"Address1": "Orce Nikolov 75",
		"Address2": "Room 301",
		"AdministrativeArea": "",
		"Country": "North Macedonia",
		"Locality": "Bitola",
		"PostalCode": "7000"
	  }
},

"BG":{
	{
		"Address1": "Ulitsa Vitosha 16",
		"Address2": "Floor 3, Suite 12",
		"AdministrativeArea": "",
		"Country": "Bulgaria",
		"Locality": "Sofia",
		"PostalCode": "1000"
	  },
	  {
		"Address1": "Bul. Tsarigradsko Shose 115G",
		"Address2": "Office 204, Level 2",
		"AdministrativeArea": "",
		"Country": "Bulgaria",
		"Locality": "Sofia",
		"PostalCode": "1784"
	  },
	  {
		"Address1": "Ul. Rakovski 145",
		"Address2": "Apt. 11",
		"AdministrativeArea": "",
		"Country": "Bulgaria",
		"Locality": "Plovdiv",
		"PostalCode": "4000"
	  },
	  {
		"Address1": "Ulitsa Slivnitsa 10",
		"Address2": "Building B, Room 7",
		"AdministrativeArea": "",
		"Country": "Bulgaria",
		"Locality": "Varna",
		"PostalCode": "9000"
	  }
},
"BE":{
	{
		"Address1": "Rue du Trône 100",
		"Address2": "Boîte 4",
		"AdministrativeArea": "",
		"Country": "Belgium",
		"Locality": "Brussels",
		"PostalCode": "1050"
	  },
	  {
		"Address1": "Avenue Louise 200",
		"Address2": "Etage 5, Bureau 3",
		"AdministrativeArea": "",
		"Country": "Belgium",
		"Locality": "Brussels",
		"PostalCode": "1050"
	  },
	  {
		"Address1": "Meir 59",
		"Address2": "Appartement 2A",
		"AdministrativeArea": "",
		"Country": "Belgium",
		"Locality": "Antwerp",
		"PostalCode": "2000"
	  },
	  {
		"Address1": "Rue Neuve 111",
		"Address2": "Box 7",
		"AdministrativeArea": "",
		"Country": "Belgium",
		"Locality": "Brussels",
		"PostalCode": "1000"
	  }
},
"MD":{
	{
		"Address1": "Strada București 68",
		"Address2": "Bloc B, Etaj 2",
		"AdministrativeArea": "",
		"Country": "Moldova",
		"Locality": "Chișinău",
		"PostalCode": "MD-2012"
	  },
	  {
		"Address1": "Str. Ismail 46",
		"Address2": "Apartment 18",
		"AdministrativeArea": "",
		"Country": "Moldova",
		"Locality": "Chișinău",
		"PostalCode": "MD-2001"
	  },
	  {
		"Address1": "Str. Stefan cel Mare 152",
		"Address2": "Etaj 5, Birou 503",
		"AdministrativeArea": "",
		"Country": "Moldova",
		"Locality": "Chișinău",
		"PostalCode": "MD-2023"
	  },
	  {
		"Address1": "Strada Mihai Eminescu 10",
		"Address2": "Room 4A",
		"AdministrativeArea": "",
		"Country": "Moldova",
		"Locality": "Bălți",
		"PostalCode": "MD-3100"
	  }
},

"HU":{
	{
		"address1": "Kossuth Lajos utca 5",
		"address2": "2nd Floor, Apt. 4",
		"administrativeArea": "Budapest",
		"country": "Hungary",
		"locality": "Budapest",
		"postalCode": "1053"
	  },
	  {
		"address1": "Petőfi Sándor utca 12",
		"address2": "Building B, Suite 3",
		"administrativeArea": "Pest",
		"country": "Hungary",
		"locality": "Szentendre",
		"postalCode": "2000"
	  }
},

"IS":{
	{
		"address1": "Laugavegur 10",
		"address2": "P.O. Box 123",
		"administrativeArea": "Capital Region",
		"country": "Iceland",
		"locality": "Reykjavík",
		"postalCode": "101"
	  },
	  {
		"address1": "Hafnarstræti 20",
		"address2": "3rd Floor, Suite 5",
		"administrativeArea": "Northeastern Region",
		"country": "Iceland",
		"locality": "Akureyri",
		"postalCode": "600"
	  }	
},

"DE":{
	{
		"address1": "Musterstraße 1",
		"address2": "Gebäude A, Zimmer 101",
		"administrativeArea": "Bavaria",
		"country": "Germany",
		"locality": "Munich",
		"postalCode": "80333"
	  },
	  {
		"address1": "Hauptstraße 15",
		"address2": "2. OG, Büro 3",
		"administrativeArea": "North Rhine-Westphalia",
		"country": "Germany",
		"locality": "Cologne",
		"postalCode": "50667"
	  }
},

"PG":{
	{
		"address1": "Section 12, Lot 34",
		"address2": "P.O. Box 567",
		"administrativeArea": "National Capital District",
		"country": "Papua New Guinea",
		"locality": "Port Moresby",
		"postalCode": "121"
	  },
	  {
		"address1": "Highlands Highway",
		"address2": "P.O. Box 890",
		"administrativeArea": "Eastern Highlands",
		"country": "Papua New Guinea",
		"locality": "Goroka",
		"postalCode": "441"
	  }
},

"CI":{
	{
		"address1": "Rue des Jardins",
		"address2": "B.P. 1234",
		"administrativeArea": "Abidjan",
		"country": "Côte d'Ivoire",
		"locality": "Abidjan",
		"postalCode": "01"
	  },
	  {
		"address1": "Avenue Chardy",
		"address2": "B.P. 5678",
		"administrativeArea": "Yamoussoukro",
		"country": "Côte d'Ivoire",
		"locality": "Yamoussoukro",
		"postalCode": "02"
	  }
},

"ES":{
	{
		"address1": "Calle de Alcalá 50",
		"address2": "4º Piso, Puerta 2",
		"administrativeArea": "Community of Madrid",
		"country": "Spain",
		"locality": "Madrid",
		"postalCode": "28014"
	  },
	  {
		"address1": "Passeig de Gràcia 15",
		"address2": "Entresuelo, Oficina 1",
		"administrativeArea": "Catalonia",
		"country": "Spain",
		"locality": "Barcelona",
		"postalCode": "08007"
	  }
},

"SE":{
	{
		"address1": "Storgatan 1",
		"address2": "Våning 2, Lägenhet 3",
		"administrativeArea": "Stockholm County",
		"country": "Sweden",
		"locality": "Stockholm",
		"postalCode": "114 51"
	  },
	  {
		"address1": "Kungsgatan 20",
		"address2": "3rd Floor, Suite 5",
		"administrativeArea": "Västra Götaland County",
		"country": "Sweden",
		"locality": "Gothenburg",
		"postalCode": "411 19"
	  }
},

"CA":{
	{
		"address1": "123 Maple Street",
		"address2": "Apt. 4B",
		"administrativeArea": "Ontario",
		"country": "Canada",
		"locality": "Toronto",
		"postalCode": "M5J 2N1"
	  },
	  {
		"address1": "456 Elm Avenue",
		"address2": "Suite 210",
		"administrativeArea": "British Columbia",
		"country": "Canada",
		"locality": "Vancouver",
		"postalCode": "V6C 1A1"
	  }
},
"PH":{
	{
		"address1": "789 Rizal Street",
		"address2": "Barangay 5, Zone 2",
		"administrativeArea": "Metro Manila",
		"country": "Philippines",
		"locality": "Manila",
		"postalCode": "1000"
	  },
	  {
		"address1": "321 Bonifacio Avenue",
		"address2": "P.O. Box 123",
		"administrativeArea": "Cebu",
		"country": "Philippines",
		"locality": "Cebu City",
		"postalCode": "6000"
	  }
},

"TJ":{
	{
		"address1": "123 Somoni Avenue",
		"address2": "Apartment 5",
		"administrativeArea": "Dushanbe",
		"country": "Tajikistan",
		"locality": "Dushanbe",
		"postalCode": "734000"
	  },
	  {
		"address1": "456 Rudaki Street",
		"address2": "Office 12",
		"administrativeArea": "Sughd",
		"country": "Tajikistan",
		"locality": "Khujand",
		"postalCode": "735700"
	  }
},

"AU":{
	{
		"address1": "25 George Street",
		"address2": "Level 3, Suite 2",
		"administrativeArea": "New South Wales",
		"country": "Australia",
		"locality": "Sydney",
		"postalCode": "2000"
	  },
	  {
		"address1": "100 Collins Street",
		"address2": "Floor 5",
		"administrativeArea": "Victoria",
		"country": "Australia",
		"locality": "Melbourne",
		"postalCode": "3000"
	  }
},

"GR":{
	{
		"address1": "123 Ermou Street",
		"address2": "2nd Floor, Office 5",
		"administrativeArea": "Attica",
		"country": "Greece",
		"locality": "Athens",
		"postalCode": "105 63"
	  },
	  {
		"address1": "456 Egnatia Street",
		"address2": "Suite 10",
		"administrativeArea": "Central Macedonia",
		"country": "Greece",
		"locality": "Thessaloniki",
		"postalCode": "546 24"
	  }
},

"IT":{
	{
		"address1": "Via Roma 123",
		"address2": "Scala A, Interno 4",
		"administrativeArea": "Lazio",
		"country": "Italy",
		"locality": "Rome",
		"postalCode": "00184"
	  },
	  {
		"address1": "Corso Vittorio Emanuele II 45",
		"address2": "Piano 3, Appartamento 7",
		"administrativeArea": "Lombardy",
		"country": "Italy",
		"locality": "Milan",
		"postalCode": "20122"
	  }
},

"DK":{
	{
		"address1": "Østerbrogade 50",
		"address2": "2. sal, Lejlighed 6",
		"administrativeArea": "Capital Region",
		"country": "Denmark",
		"locality": "Copenhagen",
		"postalCode": "2100"
	  },
	  {
		"address1": "H.C. Andersens Boulevard 35",
		"address2": "1. tv",
		"administrativeArea": "Central Denmark Region",
		"country": "Denmark",
		"locality": "Aarhus",
		"postalCode": "8000"
	  }
},

"ZA":{
	{
		"address1": "123 Main Road",
		"address2": "Flat 5B",
		"administrativeArea": "Western Cape",
		"country": "South Africa",
		"locality": "Cape Town",
		"postalCode": "8001"
	  },
	  {
		"address1": "456 Church Street",
		"address2": "Suite 12",
		"administrativeArea": "Gauteng",
		"country": "South Africa",
		"locality": "Johannesburg",
		"postalCode": "2001"
	  }
			
}

}
